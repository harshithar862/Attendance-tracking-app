import 'package:geofence_service/geofence_service.dart';
import 'package:flutter/foundation.dart';

class GeofencingService {
  final GeofenceService _geofenceService = GeofenceService.instance;

  final double officeLat = 12.9380; // Replace with actual latitude
  final double officeLng = 77.6096; // Replace with actual longitude
  final double radius = 200; // Radius in meters

  void startGeofenceMonitoring(VoidCallback onEnter, VoidCallback onExit) {
    final geofence = Geofence(
      id: 'office',
      latitude: officeLat,
      longitude: officeLng,
      radius: [GeofenceRadius(id: 'radius_200m', length: radius)],
    );

    _geofenceService
      ..addGeofenceStatusChangeListener(
        _onGeofenceStatusChanged(onEnter, onExit) as GeofenceStatusChanged,
      )
      ..start([geofence]);
  }

  Function(Geofence, GeofenceRadius, GeofenceStatus) _onGeofenceStatusChanged(
    VoidCallback onEnter,
    VoidCallback onExit,
  ) {
    return (Geofence geofence, GeofenceRadius radius, GeofenceStatus status) {
      if (status == GeofenceStatus.ENTER) {
        debugPrint('Entered geofence: ${geofence.id}');
        onEnter();
      } else if (status == GeofenceStatus.EXIT) {
        debugPrint('Exited geofence: ${geofence.id}');
        onExit();
      }
    };
  }
}
