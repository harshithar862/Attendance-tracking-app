import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash_screen.dart'; // ✅ correct import
import 'screens/dashboard_screen.dart';
import 'screens/history_screen.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/manual_check_screen.dart';
import 'firebase_options.dart'; // Make sure this import exists

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform, // ✅ IMPORTANT LINE
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Attendance App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: SplashScreen(), // ✅ Correct widget name
      routes: {
        '/dashboard': (context) => DashboardScreen(),
        '/history': (context) => HistoryScreen(),
        '/home': (context) => HomeScreen(),
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/manual-check': (context) => ManualCheckScreen(),
        // add others if needed
      },
    );
  }
}
