import 'package:geolocator/geolocator.dart';
import 'constants.dart';

Future<bool> isUserInsideGeofence() async {
  LocationPermission permission = await Geolocator.requestPermission();
  if (permission == LocationPermission.denied ||
      permission == LocationPermission.deniedForever) {
    return false;
  }

  Position position = await Geolocator.getCurrentPosition(
    desiredAccuracy: LocationAccuracy.high,
  );

  double distance = Geolocator.distanceBetween(
    officeLatitude,
    officeLongitude,
    position.latitude,
    position.longitude,
  );

  return distance <= geofenceRadius;
}
