const double officeLatitude = 13.1027; // Replace with exact value if needed
const double officeLongitude = 77.5740;
const double geofenceRadius = 200; // in meters
